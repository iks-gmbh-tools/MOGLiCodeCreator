Drop in this folder all of your jars, that you need on the classpath. 
Static methods of classes in these jars are accessible from template files!